#ifndef _lcd_h_
#define _lcd_h_

#include "stc15f2k60s2.h"
#include "delay.h"

#ifndef uchar
#define uchar unsigned char
#endif

#ifndef uint
#define uint unsigned int
#endif

#define DB P2

sbit RS=P3^5;
sbit RW=P4^2;
sbit E=P3^4;

bit LCD1602_Check_Busy();
void LCD1602_Write_Com(uchar com);
void LCD1602_Write_Data(uchar dat);
void LCD1602_Write_Char(uchar x,uchar y,uchar dat);	 //x��ʾ�У�y��ʾ�У�  dat��ʾ�ַ�
void display(uchar x,uchar y,uint dat);
void LCD1602_Write_String(uchar x,uchar y,uchar *s);
void Init1602();

#endif