#include"delay.h"

void Delay_Ms(unsigned int xms)				
{
	unsigned int i,j;
	for(i=xms;i>0;i--)		     
		for(j=2000;j>0;j--);
}