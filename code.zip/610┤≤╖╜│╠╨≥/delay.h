#ifndef _delay_h_
#define _delay_h_

void Delay_Ms(unsigned int xms);	
			
#endif